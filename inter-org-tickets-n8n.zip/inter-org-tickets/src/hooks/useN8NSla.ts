/**
 * useN8NSla
 * SLA data and operations — all routed through n8n.
 * n8n handles: deadline computation, breach detection,
 * escalation matrix execution, notification dispatch.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";

export interface SLATicket {
  id: string;
  title: string;
  customer: { name: string; avatar: string; tier: "standard" | "premium" | "enterprise" };
  priority: "low" | "medium" | "high" | "critical";
  status: "open" | "in_progress" | "resolved" | "closed";
  createdAt: string;
  sla: {
    firstResponseTarget: string;
    firstResponseTime?: string;
    firstResponseStatus: "pending" | "met" | "breached";
    resolutionTarget: string;
    resolutionTime?: string;
    resolutionStatus: "pending" | "met" | "breached";
    percentageRemaining: number;
    timeRemaining: string;
  };
  assignee?: { name: string; avatar: string };
}

export interface SLAMetrics {
  complianceRate: number;
  complianceTrend: number;
  avgResponseMinutes: number;
  avgResponseTrend: number;
  atRiskCount: number;
  breachedCount: number;
}

export function useN8NSla(filterTier?: string, filterStatus?: string) {
  const { toast } = useToast();
  const [tickets, setTickets] = useState<SLATicket[]>([]);
  const [metrics, setMetrics] = useState<SLAMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);

    const res = await n8nPost<{ tickets: SLATicket[]; metrics: SLAMetrics }>(
      N8N_WEBHOOKS.SLA_LIST,
      { filterTier, filterStatus }
    );

    if (!res.ok || !res.data) {
      const msg = res.error ?? "Failed to load SLA data";
      setError(msg);
      toast({ title: "SLA load error", description: msg, variant: "destructive" });
    } else {
      setTickets(res.data.tickets ?? []);
      setMetrics(res.data.metrics ?? null);
    }
    setLoading(false);
  }, [filterTier, filterStatus, toast]);

  useEffect(() => { load(); }, [load]);

  const escalate = useCallback(async (ticketId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.SLA_ESCALATE, { ticketId });
    if (res.ok) {
      toast({ title: "Ticket escalated", description: `${ticketId} routed to next escalation level via n8n` });
      load();
    } else {
      toast({ title: "Escalation failed", description: res.error ?? "Unknown error", variant: "destructive" });
    }
  }, [load, toast]);

  const assign = useCallback(async (ticketId: string, agentName: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.THREAD_UPDATE, { threadId: ticketId, field: "assignee", value: agentName });
    if (res.ok) {
      toast({ title: "Assigned", description: `${ticketId} assigned to ${agentName}` });
      load();
    } else {
      toast({ title: "Assignment failed", description: res.error ?? "Unknown error", variant: "destructive" });
    }
  }, [load, toast]);

  return { tickets, metrics, loading, error, escalate, assign, reload: load };
}
