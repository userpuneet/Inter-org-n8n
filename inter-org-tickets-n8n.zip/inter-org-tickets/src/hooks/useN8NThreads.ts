/**
 * useN8NThreads
 *
 * Replaces the Supabase-direct useThreads hook.
 * All thread reads & writes go through n8n webhook workflows which
 * can fan-out to Supabase, send notifications, trigger SLA timers, etc.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";
import type { Thread, ThreadStatus, ThreadPriority } from "@/types/threads";

export interface UseN8NThreadsReturn {
  threads: Thread[];
  loading: boolean;
  error: string | null;
  updateStatus: (threadId: string, status: ThreadStatus) => Promise<void>;
  updatePriority: (threadId: string, priority: ThreadPriority) => Promise<void>;
  updateAssignee: (threadId: string, assignee: string | null) => Promise<void>;
  addComment: (threadId: string, content: string, isInternal: boolean) => Promise<void>;
  reload: () => void;
}

export function useN8NThreads(): UseN8NThreadsReturn {
  const { toast } = useToast();
  const [threads, setThreads] = useState<Thread[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);

    const res = await n8nPost<Thread[]>(N8N_WEBHOOKS.THREADS_LIST, {
      limit: 200,
      orderBy: "updated_at",
    });

    if (!res.ok || !res.data) {
      const msg = res.error ?? "Failed to load threads";
      setError(msg);
      toast({ title: "Error loading threads", description: msg, variant: "destructive" });
    } else {
      setThreads(res.data);
    }

    setLoading(false);
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const updateStatus = useCallback(async (threadId: string, status: ThreadStatus) => {
    // Optimistic update
    setThreads(prev => prev.map(t => t.id === threadId ? { ...t, status } : t));

    const res = await n8nPost(N8N_WEBHOOKS.THREAD_UPDATE, { threadId, field: "status", value: status });
    if (!res.ok) {
      toast({ title: "Update failed", description: res.error ?? "Could not update status", variant: "destructive" });
      load(); // revert by reloading
    }
  }, [load, toast]);

  const updatePriority = useCallback(async (threadId: string, priority: ThreadPriority) => {
    setThreads(prev => prev.map(t => t.id === threadId ? { ...t, priority } : t));

    const res = await n8nPost(N8N_WEBHOOKS.THREAD_UPDATE, { threadId, field: "priority", value: priority });
    if (!res.ok) {
      toast({ title: "Update failed", description: res.error ?? "Could not update priority", variant: "destructive" });
      load();
    }
  }, [load, toast]);

  const updateAssignee = useCallback(async (threadId: string, assignee: string | null) => {
    setThreads(prev => prev.map(t => t.id === threadId ? { ...t, assignee } : t));

    const res = await n8nPost(N8N_WEBHOOKS.THREAD_UPDATE, { threadId, field: "assignee", value: assignee });
    if (!res.ok) {
      toast({ title: "Update failed", description: res.error ?? "Could not update assignee", variant: "destructive" });
      load();
    }
  }, [load, toast]);

  const addComment = useCallback(async (threadId: string, content: string, isInternal: boolean) => {
    const res = await n8nPost(N8N_WEBHOOKS.THREAD_COMMENT_ADD, { threadId, content, isInternal });
    if (!res.ok) {
      toast({ title: "Comment failed", description: res.error ?? "Could not post comment", variant: "destructive" });
    } else {
      toast({ title: isInternal ? "Internal note added" : "Comment posted" });
      load();
    }
  }, [load, toast]);

  return { threads, loading, error, updateStatus, updatePriority, updateAssignee, addComment, reload: load };
}
