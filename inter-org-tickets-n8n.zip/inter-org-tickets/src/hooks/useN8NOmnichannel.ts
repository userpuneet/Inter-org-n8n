/**
 * useN8NOmnichannel
 * Omnichannel inbox — n8n handles channel adapters (email/SMS/WhatsApp/etc.)
 * and routes all messages into unified thread records.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";

export interface ChannelMessage {
  id: string;
  channelType: "email" | "chat" | "sms" | "social" | "call" | "whatsapp";
  socialPlatform?: "twitter" | "facebook" | "instagram";
  direction: "incoming" | "outgoing";
  content: string;
  timestamp: string;
  sender: { name: string; avatar?: string };
  attachments?: { name: string; size: string; type: string }[];
  ticketId: string;
}

export interface OmnichannelTicket {
  id: string;
  customer: { name: string; email: string; avatar?: string; company?: string };
  subject: string;
  status: "active" | "waiting" | "resolved";
  priority: "low" | "medium" | "high" | "critical";
  channels: { email: boolean; chat: boolean; social: boolean; call: boolean; sms: boolean };
  assignedTo?: string;
  lastMessage?: string;
  lastMessageAt?: string;
  unreadCount: number;
}

export interface ChannelStatus {
  type: string;
  connected: boolean;
  label: string;
  lastSync?: string;
}

export function useN8NOmnichannel() {
  const { toast } = useToast();
  const [tickets, setTickets] = useState<OmnichannelTicket[]>([]);
  const [messages, setMessages] = useState<ChannelMessage[]>([]);
  const [channelStatuses, setChannelStatuses] = useState<ChannelStatus[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedTicketId, setSelectedTicketId] = useState<string | null>(null);

  const loadTickets = useCallback(async () => {
    setLoading(true);
    const [ticketRes, statusRes] = await Promise.all([
      n8nPost<OmnichannelTicket[]>(N8N_WEBHOOKS.OMNI_TICKETS_LIST, {}),
      n8nPost<ChannelStatus[]>(N8N_WEBHOOKS.OMNI_CHANNEL_STATUS, {}),
    ]);
    if (ticketRes.ok && ticketRes.data) setTickets(ticketRes.data);
    if (statusRes.ok && statusRes.data) setChannelStatuses(statusRes.data);
    setLoading(false);
  }, []);

  const loadMessages = useCallback(async (ticketId: string) => {
    const res = await n8nPost<ChannelMessage[]>(N8N_WEBHOOKS.OMNI_MESSAGES_LIST, { ticketId });
    if (res.ok && res.data) setMessages(res.data);
  }, []);

  useEffect(() => { loadTickets(); }, [loadTickets]);

  useEffect(() => {
    if (selectedTicketId) loadMessages(selectedTicketId);
  }, [selectedTicketId, loadMessages]);

  const selectTicket = useCallback((ticketId: string) => {
    setSelectedTicketId(ticketId);
  }, []);

  const sendMessage = useCallback(async (
    ticketId: string,
    content: string,
    channel: ChannelMessage["channelType"]
  ) => {
    const res = await n8nPost(N8N_WEBHOOKS.OMNI_SEND_MESSAGE, { ticketId, content, channel });
    if (res.ok) {
      toast({ title: "Message sent", description: `Dispatched via ${channel} through n8n` });
      if (selectedTicketId === ticketId) loadMessages(ticketId);
    } else {
      toast({ title: "Send failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [selectedTicketId, loadMessages, toast]);

  return {
    tickets, messages, channelStatuses, loading,
    selectedTicketId, selectTicket,
    sendMessage, reloadTickets: loadTickets,
  };
}
