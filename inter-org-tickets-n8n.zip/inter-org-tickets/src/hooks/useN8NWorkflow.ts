/**
 * useN8NWorkflow
 * Workflow Studio — reads & writes workflow definitions through n8n.
 * n8n is both the store AND the executor of all workflow DAGs.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";

export interface WorkflowStep {
  id: string;
  type: "start" | "end" | "condition" | "action" | "notification" | "assignment" | "approval";
  label: string;
  description?: string;
  status?: string;
  config?: Record<string, unknown>;
  x: number;
  y: number;
}

export interface WorkflowDef {
  id: string;
  name: string;
  description: string;
  status: "draft" | "active" | "inactive";
  category: string;
  steps: WorkflowStep[];
  connections: { from: string; to: string; condition?: string }[];
  triggers: { type: string; config: Record<string, unknown> }[];
  lastModified: string;
  author: { name: string; avatar: string };
  n8nWorkflowId?: string; // the actual n8n internal workflow ID
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  steps: number;
  author: { name: string; avatar: string };
  lastModified: string;
  usage: number;
}

export function useN8NWorkflow() {
  const { toast } = useToast();
  const [workflows, setWorkflows] = useState<WorkflowDef[]>([]);
  const [templates, setTemplates] = useState<WorkflowTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [wfRes, tplRes] = await Promise.all([
      n8nPost<WorkflowDef[]>(N8N_WEBHOOKS.WORKFLOW_LIST, {}),
      n8nPost<WorkflowTemplate[]>(N8N_WEBHOOKS.WORKFLOW_TEMPLATES, {}),
    ]);
    if (wfRes.ok && wfRes.data)   setWorkflows(wfRes.data);
    if (tplRes.ok && tplRes.data) setTemplates(tplRes.data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  /** Save or create a workflow — n8n stores and validates the DAG */
  const save = useCallback(async (workflow: Partial<WorkflowDef> & { name: string }) => {
    setSaving(true);
    const res = await n8nPost<WorkflowDef>(N8N_WEBHOOKS.WORKFLOW_SAVE, workflow as Record<string, unknown>);
    setSaving(false);
    if (res.ok && res.data) {
      setWorkflows(prev => {
        const idx = prev.findIndex(w => w.id === res.data!.id);
        return idx >= 0 ? prev.map((w, i) => i === idx ? res.data! : w) : [...prev, res.data!];
      });
      toast({ title: "Workflow saved", description: `"${workflow.name}" synced to n8n` });
      return res.data;
    } else {
      toast({ title: "Save failed", description: res.error ?? "n8n error", variant: "destructive" });
      return null;
    }
  }, [toast]);

  /** Activate workflow — n8n enables the trigger listeners */
  const activate = useCallback(async (workflowId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.WORKFLOW_ACTIVATE, { workflowId });
    if (res.ok) {
      setWorkflows(prev => prev.map(w => w.id === workflowId ? { ...w, status: "active" as const } : w));
      toast({ title: "Workflow activated", description: "n8n is now listening for triggers" });
    } else {
      toast({ title: "Activation failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  /** Deactivate workflow */
  const deactivate = useCallback(async (workflowId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.WORKFLOW_DEACTIVATE, { workflowId });
    if (res.ok) {
      setWorkflows(prev => prev.map(w => w.id === workflowId ? { ...w, status: "inactive" as const } : w));
      toast({ title: "Workflow deactivated" });
    } else {
      toast({ title: "Deactivation failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  /** Manually trigger a workflow execution */
  const execute = useCallback(async (workflowId: string, payload: Record<string, unknown> = {}) => {
    const res = await n8nPost(N8N_WEBHOOKS.WORKFLOW_EXECUTE, { workflowId, ...payload });
    if (res.ok) {
      toast({ title: "Workflow triggered", description: `Execution ID: ${res.executionId ?? "—"}` });
    } else {
      toast({ title: "Execution failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
    return res;
  }, [toast]);

  /** Delete a workflow from n8n */
  const remove = useCallback(async (workflowId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.WORKFLOW_DELETE, { workflowId });
    if (res.ok) {
      setWorkflows(prev => prev.filter(w => w.id !== workflowId));
      toast({ title: "Workflow deleted" });
    } else {
      toast({ title: "Delete failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  return { workflows, templates, loading, saving, save, activate, deactivate, execute, remove, reload: load };
}
