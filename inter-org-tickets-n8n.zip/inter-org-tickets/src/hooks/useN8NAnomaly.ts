/**
 * useN8NAnomaly
 * Anomaly detection — n8n runs the detection cron,
 * fires webhooks, and manages alert lifecycle.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";
import type { Alert, WebhookConfig } from "@/components/anomaly/types";

export function useN8NAnomaly(filters: { severity: string; type: string; timeRange: string; status: string }) {
  const { toast } = useToast();
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [webhooks, setWebhooks] = useState<WebhookConfig[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const [alertRes, whRes] = await Promise.all([
      n8nPost<Alert[]>(N8N_WEBHOOKS.ANOMALY_ALERTS, filters),
      n8nPost<WebhookConfig[]>(N8N_WEBHOOKS.ANOMALY_WEBHOOKS, {}),
    ]);
    if (alertRes.ok && alertRes.data) setAlerts(alertRes.data);
    if (whRes.ok && whRes.data) setWebhooks(whRes.data);
    setLoading(false);
  }, [filters]);

  useEffect(() => { load(); }, [load]);

  const resolveAlert = useCallback(async (alertId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.ANOMALY_RESOLVE, { alertId, action: "resolve" });
    if (res.ok) {
      setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, status: "resolved" as const } : a));
      toast({ title: "Alert resolved" });
    } else {
      toast({ title: "Resolve failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  const acknowledgeAlert = useCallback(async (alertId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.ANOMALY_RESOLVE, { alertId, action: "acknowledge" });
    if (res.ok) {
      setAlerts(prev => prev.map(a => a.id === alertId ? { ...a, status: "acknowledged" as const } : a));
      toast({ title: "Alert acknowledged" });
    } else {
      toast({ title: "Failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  return { alerts, webhooks, loading, resolveAlert, acknowledgeAlert, reload: load };
}
