/**
 * useN8NUsers
 * User management — reads org members from n8n,
 * which sources from the Supabase user_profiles + org_members tables.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";

export interface OrgUser {
  id: string;
  name: string;
  email: string;
  role: "admin" | "member" | "viewer";
  organization: string;
  avatar?: string;
  specialty?: string;
  status: "active" | "invited" | "inactive";
  lastActive?: string;
}

export function useN8NUsers() {
  const { toast } = useToast();
  const [users, setUsers] = useState<OrgUser[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await n8nPost<OrgUser[]>(N8N_WEBHOOKS.USERS_LIST, {});
    if (res.ok && res.data) {
      setUsers(res.data);
    } else {
      toast({ title: "Failed to load users", description: res.error ?? "n8n error", variant: "destructive" });
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => { load(); }, [load]);

  const inviteUser = useCallback(async (email: string, role: OrgUser["role"]) => {
    const res = await n8nPost(N8N_WEBHOOKS.USER_INVITE, { email, role });
    if (res.ok) {
      toast({ title: "Invitation sent", description: `Invite dispatched to ${email} via n8n` });
      load();
    } else {
      toast({ title: "Invite failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [load, toast]);

  const updateUser = useCallback(async (userId: string, updates: Partial<OrgUser>) => {
    const res = await n8nPost(N8N_WEBHOOKS.USER_UPDATE, { userId, ...updates });
    if (res.ok) {
      setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updates } : u));
      toast({ title: "User updated" });
    } else {
      toast({ title: "Update failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  return { users, loading, inviteUser, updateUser, reload: load };
}
