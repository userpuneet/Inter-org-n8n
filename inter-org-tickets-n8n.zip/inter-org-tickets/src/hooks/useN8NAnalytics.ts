/**
 * useN8NAnalytics
 * All analytics data aggregated by n8n workflows that
 * query materialized views and compute forecasts.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";

interface DataPoint { [key: string]: string | number | null }

export interface AnalyticsData {
  ticketVolume: DataPoint[];
  responseTime: DataPoint[];
  resolutionTime: DataPoint[];
  satisfaction: DataPoint[];
  categoryDistribution: DataPoint[];
  predictiveForecast: DataPoint[];
  customerSentiment: DataPoint[];
  customerJourney: DataPoint[];
  teamPerformance: DataPoint[];
}

export function useN8NAnalytics(dateRange: string, teamFilter: string) {
  const { toast } = useToast();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await n8nPost<AnalyticsData>(N8N_WEBHOOKS.ANALYTICS_OVERVIEW, { dateRange, teamFilter });
    if (res.ok && res.data) {
      setData(res.data);
    } else {
      toast({ title: "Analytics load error", description: res.error ?? "n8n error", variant: "destructive" });
    }
    setLoading(false);
  }, [dateRange, teamFilter, toast]);

  useEffect(() => { load(); }, [load]);

  return { data, loading, reload: load };
}
