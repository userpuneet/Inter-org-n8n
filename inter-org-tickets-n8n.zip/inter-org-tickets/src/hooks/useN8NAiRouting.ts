/**
 * useN8NAiRouting
 * AI classification and agent routing — fully n8n-powered.
 * n8n workflows handle: LLM classification, confidence scoring,
 * agent matching, assignment, feedback loop logging.
 */
import { useCallback, useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { n8nPost, N8N_WEBHOOKS } from "@/lib/n8n";

export interface ClassifiedTicket {
  id: string;
  title: string;
  content: string;
  category: string;
  confidence: number;
  suggestedTeam: string;
  suggestedAgent: {
    name: string;
    avatar: string;
    specialty: string;
    successRate: number;
  };
  priority: "low" | "medium" | "high" | "critical";
  status: "new" | "processed" | "assigned";
}

export interface AIMetrics {
  classificationAccuracy: number;
  classificationTrend: number;
  assignmentPrecision: number;
  assignmentTrend: number;
  avgProcessingSeconds: number;
  processingTrend: number;
  manualOverrideRate: number;
  overrideTrend: number;
}

export function useN8NAiRouting() {
  const { toast } = useToast();
  const [tickets, setTickets] = useState<ClassifiedTicket[]>([]);
  const [metrics, setMetrics] = useState<AIMetrics | null>(null);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    const [ticketsRes, metricsRes] = await Promise.all([
      n8nPost<ClassifiedTicket[]>(N8N_WEBHOOKS.AI_CLASSIFY, { fetch: true }),
      n8nPost<AIMetrics>(N8N_WEBHOOKS.AI_METRICS, {}),
    ]);

    if (ticketsRes.ok && ticketsRes.data) setTickets(ticketsRes.data);
    if (metricsRes.ok && metricsRes.data)  setMetrics(metricsRes.data);
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  /** Auto-assign a single ticket as n8n recommended */
  const assignTicket = useCallback(async (ticketId: string) => {
    const res = await n8nPost(N8N_WEBHOOKS.AI_ASSIGN, { ticketId });
    if (res.ok) {
      setTickets(prev => prev.map(t => t.id === ticketId ? { ...t, status: "assigned" as const } : t));
      toast({ title: "Ticket Assigned", description: "Assignment confirmed via n8n AI routing" });
    } else {
      toast({ title: "Assignment failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [toast]);

  /** Trigger n8n to process all new tickets through the AI classifier */
  const processAll = useCallback(async () => {
    setProcessing(true);
    const res = await n8nPost(N8N_WEBHOOKS.AI_PROCESS_ALL, {});
    setProcessing(false);
    if (res.ok) {
      toast({ title: "Processing complete", description: "All new tickets classified by n8n AI workflow" });
      load();
    } else {
      toast({ title: "Processing failed", description: res.error ?? "n8n error", variant: "destructive" });
    }
  }, [load, toast]);

  /** Log a human override — feeds the n8n feedback loop workflow */
  const logOverride = useCallback(async (ticketId: string, correctedCategory: string, reason: string) => {
    await n8nPost(N8N_WEBHOOKS.AI_ASSIGN, {
      ticketId,
      override: true,
      correctedCategory,
      reason,
    });
    toast({ title: "Override logged", description: "Feedback sent to n8n training workflow" });
    load();
  }, [load, toast]);

  return { tickets, metrics, loading, processing, assignTicket, processAll, logOverride, reload: load };
}
