
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import ThreadsPage from "./pages/ThreadsPage";
import CreateTicketPage from "./pages/CreateTicketPage";
import GroupsPage from "./pages/GroupsPage";
import ChannelsPage from "./pages/ChannelsPage";
import CalendarPage from "./pages/CalendarPage";
import AnnouncementsPage from "./pages/AnnouncementsPage";
import AnomalyDetectionPage from "./pages/AnomalyDetectionPage";
import UserManagementPage from "./pages/UserManagementPage";
import ReportsPage from "./pages/ReportsPage";

// New project management pages
import ProjectsPage from "./pages/ProjectsPage";
import KanbanBoardPage from "./pages/KanbanBoardPage";
import IssuesPage from "./pages/IssuesPage";

// New feature pages
import AIRoutingPage from "./pages/features/AIRoutingPage";
import SLAManagementPage from "./pages/features/SLAManagementPage";
import OmnichannelPage from "./pages/features/OmnichannelPage";
import CollaborativePage from "./pages/features/CollaborativePage";
import ResourcesPage from "./pages/features/ResourcesPage";
import AdvancedAnalyticsPage from "./pages/features/AdvancedAnalyticsPage";
import WorkflowStudioPage from "./pages/features/WorkflowStudioPage";
import FieldServicePage from "./pages/features/FieldServicePage";
import IntegrationsPage from "./pages/features/IntegrationsPage";
import N8NConfigPage from "./pages/admin/N8NConfigPage";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<ThreadsPage />} />
          <Route path="/threads" element={<ThreadsPage />} />
          <Route path="/create-ticket" element={<CreateTicketPage />} />
          <Route path="/groups" element={<GroupsPage />} />
          <Route path="/channels" element={<ChannelsPage />} />
          <Route path="/calendar" element={<CalendarPage />} />
          <Route path="/announcements" element={<AnnouncementsPage />} />
          <Route path="/anomaly-detection" element={<AnomalyDetectionPage />} />
          <Route path="/user-management" element={<UserManagementPage />} />
          <Route path="/reports" element={<ReportsPage />} />
          
          {/* Project Management routes */}
          <Route path="/projects" element={<ProjectsPage />} />
          <Route path="/projects/:projectKey/board" element={<KanbanBoardPage />} />
          <Route path="/projects/:projectKey/issues" element={<IssuesPage />} />
          
          {/* Feature routes */}
          <Route path="/analytics" element={<AdvancedAnalyticsPage />} />
          <Route path="/ai-routing" element={<AIRoutingPage />} />
          <Route path="/sla-management" element={<SLAManagementPage />} />
          <Route path="/omnichannel" element={<OmnichannelPage />} />
          <Route path="/collaborative" element={<CollaborativePage />} />
          <Route path="/resources" element={<ResourcesPage />} />
          <Route path="/workflow" element={<WorkflowStudioPage />} />
          <Route path="/field-service" element={<FieldServicePage />} />
          <Route path="/integrations" element={<IntegrationsPage />} />

          {/* n8n admin */}
          <Route path="/admin/n8n" element={<N8NConfigPage />} />
          
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
